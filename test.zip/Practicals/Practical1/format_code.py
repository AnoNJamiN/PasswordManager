from pygments import highlight
from pygments.lexers import get_lexer_by_name
from pygments.formatters import HtmlFormatter

def create_jupyter_cell(code_string, language='python', cell_number=1):
    """
    Takes a string of code and returns a complete HTML snippet
    styled like a Jupyter Notebook cell.
    """
    # --- 1. Set up the Pygments highlighter ---
    lexer = get_lexer_by_name(language, stripall=True)
    # The formatter creates HTML with inline styles for portability.
    formatter = HtmlFormatter(noclasses=True, style='default')
    highlighted_code = highlight(code_string, lexer, formatter)

    # --- 2. Define the HTML and CSS template ---
    html_template = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Jupyter Cell</title>
    <style>
        body {{
            background-color: #f5f5f5;
            font-family: 'Helvetica Neue', Arial, sans-serif;
            padding: 20px;
        }}
        .cell {{
            background-color: #fff;
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            margin-bottom: 20px;
            padding: 15px;
        }}
        .input-prompt {{
            color: #303f9f;
            font-family: monospace;
            font-size: 13px;
            margin-right: 10px;
            user-select: none;
            vertical-align: top;
        }}
        pre {{
            margin: 0;
            background-color: #f7f7f7;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            white-space: pre-wrap;
            word-wrap: break-word;
            font-size: 14px;
            line-height: 1.5;
        }}
    </style>
</head>
<body>
    <div class="cell">
        <table>
            <tr>
                <td class="input-prompt">In [{cell_number}]:</td>
                <td style="width:100%;">
                    <pre>{highlighted_code}</pre>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>
    """
    return html_template

# --- EXAMPLE USAGE ---
if __name__ == '__main__':
    my_code = """
def str_to_lst(s):
    lst = []
    for c in s:
        if c.isalpha():
            lst.append(ord(c) - ord('a'))  # Convert a-z to 0-25
        else:
            lst.append(ord(c))  # Keep the character itself (not ord)
    return lst

def lst_to_str(lst):
    result = ''
    for n in lst:
        if isinstance(n, int):
            result += chr(n + ord('a'))  # Convert 0-25 back to a-z
        else:
            result += n  # Non-letter (like space, punctuation)
    return result


def vighere_cipher(text, key):
    text = text.lower()
    key = key.lower()
    
    text_list = str_to_lst(text)
    key_list = str_to_lst(key)
    key_len = len(key_list)

    encrypted_list = []
    for i in range(len(text_list)):
        temp = (text_list[i] + key_list[i % key_len]) % 26
        encrypted_list.append(temp)

    return lst_to_str(encrypted_list)

def vighere_cipher_decrypt(text, key):
    text = text.lower()
    key = key.lower()
    
    text_list = str_to_lst(text)
    key_list = str_to_lst(key)
    key_len = len(key_list)

    encrypted_list = []
    for i in range(len(text_list)):
        temp = (text_list[i] - key_list[i % key_len]) % 26
        encrypted_list.append(temp)

    return lst_to_str(encrypted_list)


"""

    # Generate the HTML
    final_html = create_jupyter_cell(my_code, language='python')

    # Save the output to a file
    with open("jupyter_cell_output.html", "w") as f:
        f.write(final_html)

    print("Successfully created 'jupyter_cell_output.html'")